public class CountryDto {
    public CountryDto(String code, String pictureUrl) {
        this.code = code;
        this.pictureUrl = pictureUrl;
    }

    public String pictureUrl;
    public String code;
}